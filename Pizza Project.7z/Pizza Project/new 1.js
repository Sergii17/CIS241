<! DOCTYPE html>
<head>
<script type="text/javascript">

function checkbox()
{
    var bk=document.getElementById("bk").checked;;
    var cer=document.getElementById("cr").checked;
    if(bk) document.writeln(" Bike");
    if(cer) document.write(" Car");   
return false;   
}
</script>
</head>
<body>
<form>
    <input type="checkbox" id="bk" name="vehicle" value="Bike">I have a bike<br></br>
    <input type="checkbox" id="cr" name="vehicle" value="Car">I have a car<br></br> 
     <input type="submit" value="   Print   " size="30" onClick="return checkbox();">
</form> 
</body>
</html>